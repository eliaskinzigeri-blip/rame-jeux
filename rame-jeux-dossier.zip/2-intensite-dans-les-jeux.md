# Comment les jeux règlent l'intensité

Code : `code/intensity.js` (le régulateur), `code/sources.js` (fonction `setupControl`, réglage Bluetooth) et `code/games/*.js` (les règles de chaque jeu).

## 1. Le principe : un niveau unique de 0 à 1

Tous les jeux parlent au même régulateur, `Intensity`, qui gère un niveau entre **0 (très léger)** et **1 (très dur)**.

- Chaque partie démarre à **0,35**.
- Un jeu peut :
  - **changer durablement le niveau** : `set(niveau)` ou `nudge(+0,08)`, par exemple le coach de la Course ;
  - **ajouter un effet temporaire** : `bump(+0,3, 5 s)`, par exemple le kraken qui t'agrippe. L'effet disparaît tout seul à la fin du délai.
- Niveau effectif = niveau durable + effets en cours, borné entre 0 et 1.
- Chaque changement affiche une alerte à l'écran (« Le kraken t'agrippe ! Résistance ▲ ») et fait bouger la jauge « Résistance » du tableau de bord.
- Option « Résistance pilotée par le jeu : Oui / Non » à chaque partie. Avec « Non », le niveau reste à 0,35.

## 2. Deux façons d'appliquer le niveau

### a) Vraie résistance, via la console Bluetooth (FTMS)
À la connexion, l'app :
1. prend le contrôle de la console via le *Fitness Machine Control Point* (0x2AD9), avec l'opcode `0x00` puis `0x07` pour démarrer ;
2. regarde si la console annonce le réglage de résistance : caractéristique *Fitness Machine Feature* 0x2ACC, 2e mot, bit 2 ;
3. lit la plage de résistance de la console : caractéristique 0x2AD6 (min, max, pas), par exemple 1 à 16.

Le niveau 0–1 est converti en niveau console : `min + (max − min) × niveau`, arrondi au pas. Exemple : 0,35 donne 6/16.
L'ordre envoyé est l'opcode **`0x04` (résistance cible)**. Toutes les consoles ne lisent pas la norme de la même façon, donc l'app essaie dans cet ordre :
1. valeur sur 2 octets en dixièmes ;
2. valeur sur 1 octet en dixièmes ;
3. niveau brut.

Elle garde le premier format que la console accepte (réponse `0x80 0x04 0x01` = succès). Si la console répond « contrôle perdu » (code 5), l'app redemande le contrôle.
Pour ne pas saturer la console, l'app envoie **au plus 1 ordre toutes les 0,7 s** et ne garde que le dernier ordre en attente.

### b) Résistance simulée (console qui refuse, ou pas de Bluetooth)
Le bateau devient plus lourd dans le jeu : `vitesse affichée = vitesse × (1 − (niveau − 0,35) × 0,45)`.
Au niveau maximum, on perd environ 30 % de vitesse pour le même effort. Au niveau minimum, on gagne environ 15 %.
L'écran de réglage de la partie indique lequel des deux modes est actif.

## 3. Les règles de chaque jeu

| Jeu | Événement | Effet sur le niveau |
|---|---|---|
| **Fuite du kraken** | Le kraken arrive à moins de 9 m : une tentacule agrippe le bateau | **+0,30 pendant 5 s** (au plus une fois toutes les 12 s) |
| | Bouée dorée passée plus vite que le kraken | **−0,25 pendant 4 s**, et la tentacule lâche |
| | Toutes les 90 s de survie : « l'eau s'épaissit » | **+0,06** durable |
| **Course** | Toutes les 20 s, dès 30 s de course : plus de 15 m d'avance sur le meilleur adversaire (« trop facile ») | **+0,08** durable |
| | Plus de 30 m de retard sur le premier | **−0,08** durable |
| **Séances** | Chaque étape fixe un niveau selon la cadence visée : 28 cpm ou plus → 0,70 ; 25 et plus → 0,60 ; 22 et plus → 0,45 ; récup → 0,28 | niveau fixé à chaque changement d'étape |
| | En effort, cadence au-dessus de la cible de plus de 3 cpm pendant 12 s (« tu es à l'aise ») | **+0,06** sur les étapes d'effort (bonus cumulé max +0,25) |
| **Chasse aux bouées** | Série de 3 bouées éclatées | **+0,06** durable (et l'allure cible monte de 3 %) |
| | Bouée ratée | **−0,04** durable |
| **Balade** | Première rafale entre 1 et 2 min, puis toutes les 50 à 120 s. Vent de face dans 60 % des cas | Vent de face : **+0,25 pendant 20 à 40 s**, l'eau s'agite |
| | Vent arrière | **−0,20 pendant 20 à 40 s** |
| **Cadence** | Jeu de rythme | aucun changement |

À la fin de la partie (ou si tu quittes), la résistance revient au niveau de départ.

## 4. Ce qui a été vérifié

- Avec une console Bluetooth simulée qui accepte le réglage, en Fuite du kraken (difficulté « dur »), le jeu a envoyé à la console les niveaux **6** (départ), **11** (le kraken agrippe) et **6** (fin de l'effet). Voir `captures/08b-kraken-agrippe-resistance.png`.
- **Pas encore testé sur le vrai Woodrower** : on ne sait pas si sa console accepte qu'une app règle la résistance. Si la molette est manuelle, l'app passe en résistance simulée.
