# Rame & Jeux : dossier

Contenu du zip :

| Fichier | Contenu |
|---|---|
| `0-CONSIGNES.md` | **À lire en premier** : ce qu'il faut faire (onglet Jeux, pas de jeux dans les séances, micro réservé aux jeux) |
| `1-LISEZ-MOI.md` | Ce sommaire |
| `2-intensite-dans-les-jeux.md` | Comment chaque jeu règle la résistance (vraie résistance Bluetooth ou simulée), avec les chiffres exacts |
| `3-detection-au-micro.md` | Comment le micro détecte les coups, et ce qui réduit la latence (compensation, calibrage, prédiction) |
| `captures/` | Les écrans de l'app |
| `code/` | Les fichiers source concernés, copiés tels quels depuis le dépôt `rame-jeux` |

## Les captures

| Capture | Écran |
|---|---|
| `01-creation-compte.png` | Création de compte à l'arrivée (pseudo, e-mail, mot de passe) |
| `02-accueil-micro-et-latence.png` | Accueil : sources, niveau du micro et sensibilité, compensation de latence, liste des jeux |
| `03-calibrage-latence.png` | Calibrage de la latence (12 bips) |
| `03b-reglages-partie.png` | Réglages d'une partie, avec l'option « Résistance pilotée par le jeu » |
| `04-course.png` | Course de 1 000 m contre 3 bateaux, classement en direct |
| `05-balade.png` | Balade sur le lac |
| `06-seances.png` | Séance guidée (cadence cible, consigne « Accélère / Ralentis ») |
| `07-chasse-aux-bouees.png` | Chasse aux bouées |
| `08-kraken.png` | Fuite du kraken (caméra tournée vers l'arrière) |
| `08b-kraken-agrippe-resistance.png` | Le kraken agrippe le bateau : la résistance monte |
| `09-cadence.png` | Jeu de rythme Cadence |
| `10-resultat.png` | Écran de fin de partie avec le record |
| `11-accueil-records.png` | Accueil après une partie, avec les records |

## Comment les captures ont été faites

- **Rameur** : les jeux tournent avec le « rameur virtuel » (mode Simulation), sauf la capture du micro, faite avec un fichier son simulé de coups de rame.
- **Console** : pour montrer la jauge « 6 / 16 », une console Bluetooth simulée qui accepte le réglage de la résistance a été branchée.
- **Graphismes** : la 3D est en qualité « haute ». Dans l'outil de capture, elle est calculée sans carte graphique, donc l'animation y est saccadée. Ce n'est pas représentatif d'un vrai appareil.

**Rien de tout ça n'a encore été testé sur le vrai Woodrower.**
