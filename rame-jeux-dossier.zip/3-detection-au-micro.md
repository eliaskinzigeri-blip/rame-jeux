# Comment fonctionne la détection des coups au micro

Code : `code/sources.js` (fonction `mic()`), `code/rower.js` (compensation et prédiction) et `code/main.js` (jauge, sensibilité, calibrage).

## 1. Pourquoi le micro

En Bluetooth, la console envoie environ **1 mesure par seconde** et compte le coup **en fin de poussée**. Le jeu apprend donc ton coup **0,5 à 1 s** après ton geste.
Le micro, lui, entend la roue et la sangle **accélérer dès l'attaque**. Le délai tombe à quelques dizaines de millisecondes.
Le micro peut se combiner avec le Bluetooth : il donne le **rythme** des coups, et la console garde les **mesures** (allure, watts, distance, cadence).

## 2. La chaîne audio

1. **Micro brut** : `getUserMedia` avec l'annulation d'écho, la réduction de bruit et le gain automatique **désactivés**. Ces traitements « lissent » justement les montées de volume qu'on cherche.
2. **Filtre passe-haut à 120 Hz** : il coupe le grondement du sol et les chocs sourds.
3. **Mesure du volume (RMS)** sur 512 échantillons, soit environ 11 ms de son, **toutes les 8 ms**.

## 3. La détection : une montée brutale du volume, pas un seuil fixe

Une première version comparait le volume à un seuil fixe. Elle se trompait : le bruit de la roue pendant le retour dépassait aussi le seuil, ce qui donnait **2 coups détectés par coup réel**.

La version actuelle cherche une **montée brutale** :

- elle garde l'historique des **384 dernières ms** de volume (48 mesures) ;
- **volume de référence** = le minimum mesuré entre **120 ms et 380 ms dans le passé** ;
- **seuil** = référence × **sensibilité** (1,8 par défaut, réglable de 1,2 à 4) + 0,003 ;
- **un coup est détecté** si :
  - le volume dépasse le seuil,
  - **et** le volume est en train de monter,
  - **et** au moins max(0,85 s ; 55 % de la durée d'un coup) s'est écoulé depuis le coup précédent (anti-doublon).

Pendant le retour, le bruit de la roue **décroît**. Il ne monte donc jamais brutalement et ne déclenche rien.
La **force du coup** est estimée en comparant le pic de volume aux pics précédents. Elle sert à pousser le bateau plus ou moins fort.

## 4. Réglages à l'écran

- **Barre « Niveau du micro »** : volume en direct (vert) et seuil (trait orange). La barre doit dépasser le trait **à chaque poussée**, et pas au retour.
- **Curseur « Sensibilité »** :
  - monte-le si des coups sont ratés ;
  - baisse-le s'il y a des coups en trop (pièce bruyante, musique).
- Pose l'appareil **près de la roue** du rameur.

## 5. Ce qui complète le micro (valable pour toutes les sources)

- **Compensation de latence** : chaque source a un retard typique (micro 50 ms, téléphone sur le siège 120 ms, Bluetooth 650 ms). L'instant du coup est reculé d'autant, ce qui sert à l'animation et au jugement du jeu Cadence.
- **Calibrage (bouton « Calibrer (30 s) »)** : tu attaques sur 12 bips. L'app mesure le délai médian entre chaque bip et le coup reçu, puis l'enregistre pour cette source. En test, un délai simulé de 300 ms a été mesuré à **300 ms**.
- **Prédiction** : quand tu rames régulièrement, le coup suivant est joué à l'instant prévu (poussée du bateau et animation du rameur) sans attendre le capteur. Le vrai coup recale seulement le rythme, sans pousser le bateau une 2e fois. Si tu t'arrêtes, un seul coup anticipé est joué, puis le bateau ralentit.

## 6. Ce qui a été vérifié

- **Test avec un son simulé** de coups de rame à 24 cpm : bruit de fond, montée forte à chaque poussée, bruit de roue décroissant au retour.
  - Première version : **20 détections pour 12 coups** (doublons au retour).
  - Version actuelle : **12 coups détectés sur 12**, à **2,5 s d'écart exact**, **aucune fausse détection**.
- Délai estimé sur ce son : **20 à 30 ms**, sans compter le micro de l'appareil.
- **Pas encore testé sur le vrai Woodrower.** S'il est très silencieux (résistance magnétique), le micro devra être posé tout près de la roue.
